const RelatedSongs = () => (
  <div>Loader</div>
);

export default RelatedSongs;
